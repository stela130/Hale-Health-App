package com.example.halehealth.view

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.halehealth.AppDataBase.DBHelper
import com.example.halehealth.R
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.util.Calendar
import java.util.Locale


class ActivityCadastro2 : AppCompatActivity() {

    private lateinit var userDnc: TextView
    private lateinit var userGenero: EditText
    private lateinit var userAltura: EditText
    private lateinit var userPeso: EditText
    private lateinit var botaoCadastrar: Button
    private lateinit var bd: DBHelper

    private lateinit var valorGenero: TextView

    private lateinit var dataNascimento : TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro2)
        enableEdgeToEdge()

        supportActionBar?.hide()

        userDnc = findViewById(R.id.edit_dataNascimento)
        userGenero = findViewById(R.id.edit_genero)
        userAltura = findViewById(R.id.edit_altura)
        userPeso = findViewById(R.id.edit_peso)
        botaoCadastrar = findViewById(R.id.cadastrar)
        bd = DBHelper(this)

        valorGenero = findViewById(R.id.edit_genero)

        botaoCadastrar.setOnClickListener {
            val dnctext = userDnc.text.toString()
            val generotext = userGenero.text.toString()
            val alturatext = userAltura.text.toString()
            val pesotext = userPeso.text.toString()

            val nome = intent.getStringExtra("nome")
            val email = intent.getStringExtra("email")
            val senha = intent.getStringExtra("senha")

            if (TextUtils.isEmpty(dnctext) || TextUtils.isEmpty(generotext) || TextUtils.isEmpty(alturatext) || TextUtils.isEmpty(pesotext)) {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show()
            } else {
                val saveData = bd.inserirDados(dnctext, generotext, alturatext, pesotext, nome, email, senha)

                if (saveData) {
                    Toast.makeText(this, "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show()
                    val intent = Intent(applicationContext, ActivityLogin::class.java)
                    intent.putExtra("nomeUsuario", nome)
                    intent.putExtra("emailUsuario", email)
                    intent.putExtra("senhaUsuario", senha)
                    intent.putExtra("pesoUsuario", pesotext)
                    intent.putExtra("dncUsuario", dnctext)
                    intent.putExtra("generoUsuario", generotext)
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "Erro ao cadastrar. Tente novamente!", Toast.LENGTH_SHORT).show()
                }
            }
        }

        dataNascimento = findViewById(R.id.edit_dataNascimento)

        val calendario = Calendar.getInstance()

        val datePicker = DatePickerDialog.OnDateSetListener { view, year, month, dayOfMonth ->
            calendario.set(Calendar.YEAR, year)
            calendario.set(Calendar.MONTH, month)
            calendario.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            updateCalendario(calendario)
        }


        dataNascimento.setOnClickListener{
            DatePickerDialog(this, datePicker, calendario.get(Calendar.YEAR), calendario.get(
                Calendar.MONTH), calendario.get(Calendar.DAY_OF_MONTH)).show()
        }
    }

    private fun updateCalendario(calendario: Calendar) {
        val meuFormato = "dd-MM-yyyy"
        val formato = android.icu.text.SimpleDateFormat(meuFormato, Locale.ROOT)
        dataNascimento.setText(formato.format(calendario.time))
    }


    fun voltarCadastro(view: View) {
        finish()
    }

    var botaoSelecionado = 2
    val generos = arrayOf("Masculino", "Feminino")
    fun escolhaGenero(view: View) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Gênero: ")
            .setPositiveButton("Ok"){ _,_ ->
                when(botaoSelecionado){
                    0 -> {
                        valorGenero.setText("Masculino")
                    }

                    1 ->{
                        valorGenero.setText("Feminino")
                    }

                }
            }

            .setSingleChoiceItems(generos, botaoSelecionado){_, selectItemIndex ->
                botaoSelecionado = selectItemIndex
            }
            .setCancelable(false)
            .show()
    }


}
