package com.example.halehealth.AppDataBase

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import java.security.MessageDigest


class DBHelper (context: Context) : SQLiteOpenHelper(context, BD_NAME, null, VERSAO) {


    companion object {
        private const val BD_NAME = "HaleHealth.db"
        private const val VERSAO = 2
        private const val TABELA = "Usuarios"
        private const val ID = "id"
        private const val NOME = "nome"
        private const val EMAIL = "email"
        private const val SENHA = "senha"
        private const val DNC = "dnc"
        private const val GENERO = "genero"
        private const val ALTURA = "altura"
        private const val PESO = "peso"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = ("CREATE TABLE IF NOT EXISTS $TABELA ("
                + "$ID INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "$NOME TEXT, "
                + "$EMAIL TEXT, "
                + "$SENHA TEXT, "
                + "$DNC INT, "
                + "$GENERO TEXT, "
                + "$ALTURA INT, "
                + "$PESO REAL)")
        db.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABELA")
        onCreate(db)
    }



    fun inserirDados(
        dnc: String,
        genero: String,
        altura: String,
        peso: String,
        nome: String?,
        email: String?,
        senha: String?
    ): Boolean {
        val db = this.writableDatabase
        val senhaCriptografada = senha?.let { hashSHA256(it) }
        val dados = ContentValues().apply {
            put(NOME, nome)
            put(EMAIL, email)
            put(SENHA, senhaCriptografada)
            put(DNC, dnc)
            put(GENERO, genero)
            put(ALTURA, altura)
            put(PESO, peso)
        }
        val result = db.insert(TABELA, null, dados)
        return result != -1L
    }

    fun hashSHA256(senha: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(senha.toByteArray())
        return hashBytes.joinToString("") { "%02x".format(it) }
    }


    fun checkSenha(email: String, senha: String): Boolean {
        val db = this.readableDatabase
        val senhaCriptografada = hashSHA256(senha)

        val cursor = db.query(
            TABELA,
            arrayOf("SENHA"),
            "EMAIL = ? AND SENHA = ?",
            arrayOf(email, senhaCriptografada),
            null, null, null
        )

        val senhaCorreta = cursor.moveToFirst()
        cursor.close()
        return senhaCorreta
    }

    data class User(val nome: String, val email: String)
    
    @SuppressLint("Range")
    fun getUserByEmail(email: String): User? {
        val db = this.readableDatabase
        val cursor = db.query("Usuarios", null, "email = ?", arrayOf(email), null, null, null)
        if (cursor.moveToFirst()) {
            val nome = cursor.getString(cursor.getColumnIndex("nome"))
            val email = cursor.getString(cursor.getColumnIndex("email"))
            cursor.close()
            return User(nome, email)
        }
        cursor.close()
        return null
    }

    @SuppressLint("Range")
    fun getUsuario(email: String): Usuario? {
        val db = this.readableDatabase
        val cursor = db.query("Usuarios", null, "email = ?", arrayOf(email), null, null, null)

        if (cursor.moveToFirst()) {
            val nome = cursor.getString(cursor.getColumnIndex("nome"))
            val dnc = cursor.getString(cursor.getColumnIndex("dnc"))
            val genero = cursor.getString(cursor.getColumnIndex("genero"))
            val altura = cursor.getInt(cursor.getColumnIndex("altura"))
            val peso = cursor.getInt(cursor.getColumnIndex("peso"))

            cursor.close()
            return Usuario(nome, email, dnc, genero, altura, peso)
        }

        cursor.close()
        return null
    }

    data class Usuario(
        val nome: String,
        val email: String,
        val dnc: String,
        val genero: String,
        val altura: Int,
        val peso: Int
    )


    fun emailExist(email: String): Boolean {
        val db = this.readableDatabase
        val cursor = db.query(TABELA, null, "$EMAIL = ?", arrayOf(email), null, null, null)
        val exists = cursor.count > 0
        cursor.close()
        return exists
    }

}






