package com.example.halehealth.view

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.system.Os.remove
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.SwitchCompat
import androidx.appcompat.widget.Toolbar
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.example.halehealth.AppDataBase.DBHelper
import com.example.halehealth.MainActivity
import com.example.halehealth.R
import com.google.android.material.bottomappbar.BottomAppBar
import com.google.android.material.navigation.NavigationView

class ActivityHome : AppCompatActivity() {

    lateinit var drawerLayout : DrawerLayout
    private lateinit var receber: BroadcastReceiver

    private lateinit var bd: DBHelper
    private lateinit var navPerfil : NavigationView

    private var isTemaClaro: Boolean = true


    @SuppressLint("Range", "MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val btAtivarFrequencia = findViewById<AppCompatButton>(R.id.btn_cardiaco)
        val btAtivarOxigenacao = findViewById<AppCompatButton>(R.id.btn_oxigenio)

        drawerLayout = findViewById<DrawerLayout>(R.id.drawer_layout)

        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        val toggle = ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_nav,R.string.close_nav)
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()


        btAtivarFrequencia.setOnClickListener{
            val message : String? = "Aaa"
            popupMedirBPM(message)
        }

        btAtivarOxigenacao.setOnClickListener{
            val message : String? = "Aaa"
            popupMedirSP0(message)
        }



        bd = DBHelper(this)
        navPerfil = findViewById(R.id.nav_perfil)

        val sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        val editor = sharedPreferences.edit()

        val nome = intent.getStringExtra("USER_NAME")
        val email = intent.getStringExtra("USER_EMAIL")



        if (nome != null && email != null) {
            editor.putString("USER_NAME", nome)
            editor.putString("USER_EMAIL", email)
            editor.apply()
        }

        val savedNome = sharedPreferences.getString("USER_NAME", null)
        val savedEmail = sharedPreferences.getString("USER_EMAIL", null)

        updateHeader(savedNome, savedEmail)
        updateUserData()


        SharedViews.fitaPerfil2 = findViewById(R.id.fita_perfil2)
        SharedViews.fitaPerfil3 = findViewById(R.id.fita_perfil3)
        SharedViews.fitaPerfil4 = findViewById(R.id.fita_perfil4)

        val sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        isTemaClaro = sharedPref.getBoolean("isTemaClaro", true)

        aplicarTema()

        navPerfil.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.temaClaro -> {
                    isTemaClaro = !isTemaClaro
                    sharedPref.edit().putBoolean("isTemaClaro", isTemaClaro).apply()
                    aplicarTema()

                    menuItem.title = if (isTemaClaro) "Tema claro" else "Tema escuro"
                    menuItem.isChecked = true
                    true
                }
                R.id.logoutConta -> {
                    popupLogout("Você quer sair?")
                    true
                }

                R.id.menu_permissoes -> {
                    popupPermissoes("Popup Permissoes")
                    true
                }

                R.id.privacidade -> {
                    popupPrivacidade("Popup Privacidade")
                    true
                }

                else -> false
            }
        }
    }

    private fun aplicarTema() {
        val headerView = navPerfil.getHeaderView(0)
        val header: View = headerView.findViewById(R.id.header)
        val txtNomeUser: TextView = headerView.findViewById(R.id.txt_nomeUser)
        val txtEmailUser: TextView = headerView.findViewById(R.id.txt_emailUser)
        val imgPerfil: ImageView = headerView.findViewById(R.id.img_perfil)
        val fitaPerfil1: ImageView = findViewById(R.id.fita_perfil11)
        val botaoPerfil: ImageView = findViewById(R.id.botao_perfil)
        val toolbar: Toolbar = findViewById(R.id.toolbar)

        val colorResId = if (isTemaClaro) R.color.azul_logo_bottom else R.color.verde_logo_bottom
        val colorRes = if (isTemaClaro) R.color.clicadoNav else R.color.verde_clicadoNav

        findViewById<ImageView>(R.id.dados_simb1).setColorFilter(ContextCompat.getColor(this, colorRes), PorterDuff.Mode.SRC_IN)
        findViewById<ImageView>(R.id.cores_simb1).setColorFilter(ContextCompat.getColor(this, colorResId), PorterDuff.Mode.SRC_IN)
        findViewById<ImageView>(R.id.dispositivo_simb1).setColorFilter(ContextCompat.getColor(this, colorResId), PorterDuff.Mode.SRC_IN)
        findViewById<ImageView>(R.id.config_simb1).setColorFilter(ContextCompat.getColor(this, colorResId), PorterDuff.Mode.SRC_IN)


        if (isTemaClaro) {

            navPerfil.setBackgroundColor(ContextCompat.getColor(this, R.color.azul_perfil))
            header.setBackgroundColor(ContextCompat.getColor(this, R.color.azul_perfil))
            txtNomeUser.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtEmailUser.setTextColor(ContextCompat.getColor(this, R.color.degrade_botao))
            imgPerfil.clearColorFilter()
            fitaPerfil1.setBackgroundResource(R.drawable.fita_perfil)
            botaoPerfil.setBackgroundResource(R.drawable.botao_perfil)
            toolbar.setBackgroundResource(R.drawable.icon_perfil)
            mudarCorTexto(navPerfil, R.color.black)

            findViewById<DrawerLayout>(R.id.drawer_layout).setBackgroundResource(R.drawable.background_padrao)
            findViewById<TextView>(R.id.txt_dados).setTextColor(ContextCompat.getColor(this, R.color.white))
            findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.btn_cardiaco).background = ContextCompat.getDrawable(this, R.drawable.btn_borda)
            findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.btn_cardiaco).setTextColor(ContextCompat.getColor(this, R.color.white))

            findViewById<View>(R.id.linha_dados).setBackgroundResource(R.drawable.linha_branca)
            findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.btn_oxigenio).background = ContextCompat.getDrawable(this, R.drawable.btn_borda)
            findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.btn_oxigenio).setTextColor(ContextCompat.getColor(this, R.color.white))

            findViewById<View>(R.id.cardiaco_dados).setBackgroundResource(R.drawable.retangulo)
            findViewById<View>(R.id.oxigenio_dados).setBackgroundResource(R.drawable.retangulo)
            findViewById<ImageView>(R.id.dados_gerais).setBackgroundResource(R.drawable.retangulo_dados)

            val bottomAppBar = findViewById<BottomAppBar>(R.id.barra_nav)
            bottomAppBar.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, R.color.nav1))


        } else {

            navPerfil.setBackgroundColor(ContextCompat.getColor(this, R.color.verde_perfil))
            header.setBackgroundColor(ContextCompat.getColor(this, R.color.verde_perfil))
            txtNomeUser.setTextColor(ContextCompat.getColor(this, R.color.white))
            txtEmailUser.setTextColor(ContextCompat.getColor(this, R.color.white))
            imgPerfil.setColorFilter(ContextCompat.getColor(this, R.color.white))
            fitaPerfil1.setBackgroundResource(R.drawable.fita_verde_perfil)
            botaoPerfil.setBackgroundResource(R.drawable.botao_verde_perfil)
            toolbar.setBackgroundResource(R.drawable.icon_perfil_branco)
            mudarCorTexto(navPerfil, R.color.white)

            findViewById<DrawerLayout>(R.id.drawer_layout).setBackgroundResource(R.drawable.background_padrao_claro)
            findViewById<TextView>(R.id.txt_dados).setTextColor(ContextCompat.getColor(this, R.color.black))
            findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.btn_cardiaco).background = ContextCompat.getDrawable(this, R.drawable.btn_borda_claro)
            findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.btn_cardiaco).setTextColor(ContextCompat.getColor(this, R.color.black))
            findViewById<View>(R.id.linha_dados).setBackgroundResource(R.drawable.linha_preta)
            findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.btn_oxigenio).background = ContextCompat.getDrawable(this, R.drawable.btn_borda_claro)
            findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.btn_oxigenio).setTextColor(ContextCompat.getColor(this, R.color.black))

            findViewById<View>(R.id.cardiaco_dados).setBackgroundResource(R.drawable.retangulo_claro)
            findViewById<View>(R.id.oxigenio_dados).setBackgroundResource(R.drawable.retangulo_claro)
            findViewById<ImageView>(R.id.dados_gerais).setBackgroundResource(R.drawable.retangulo_dados_claro)

            val bottomAppBarClaro = findViewById<BottomAppBar>(R.id.barra_nav)
            bottomAppBarClaro.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, R.color.navClaro))

        }


        SharedViews.fitaPerfil2?.setBackgroundResource(if (isTemaClaro) R.drawable.fita_perfil else R.drawable.fita_verde_perfil)
        SharedViews.fitaPerfil3?.setBackgroundResource(if (isTemaClaro) R.drawable.fita_perfil else R.drawable.fita_verde_perfil)
        SharedViews.fitaPerfil4?.setBackgroundResource(if (isTemaClaro) R.drawable.fita_perfil else R.drawable.fita_verde_perfil)


    }

    object SharedViews {

        var fitaPerfil2: ImageView? = null
        var fitaPerfil3: ImageView? = null
        var fitaPerfil4: ImageView? = null


        var dadosSimb2: ImageView? = null
        var coresSimb2: ImageView? = null
        var dispositivoSimb2: ImageView? = null
        var configSimb2: ImageView? = null


        var dadosSimb3: ImageView? = null
        var coresSimb3: ImageView? = null
        var dispositivoSimb3: ImageView? = null
        var configSimb3: ImageView? = null

        var dadosSimb4: ImageView? = null
        var coresSimb4: ImageView? = null
        var dispositivoSimb4: ImageView? = null
        var configSimb4: ImageView? = null

        var background2 : ConstraintLayout? = null
        var background3 : ConstraintLayout? = null
        var background4 : ConstraintLayout? = null

        var tituloCores : TextView? = null

        var linhaCoresConfiguracoes : TextView? = null
        var linhaCoresConfiguracoes2 : TextView? = null
        var linhaCoresConfiguracoes3 : AppCompatButton? = null
        var linhaCoresConfiguracoes3meio : AppCompatButton? = null
        var linhaCoresConfiguracoes4 : AppCompatButton? = null
        var linhaCoresConfiguracoes5 : AppCompatButton? = null

        var retaDispositivo: ImageView? = null
        var linhaCoresDispositivo : TextView? = null
        var linhaCoresDispositivo2 : AppCompatButton? = null
        var linhaCoresDispositivo3 : AppCompatButton? = null
        var botaoVerde : Button? = null
        var textVerde : TextView? = null
        var retanguloDadosDisp : View? = null

        var botaoVerdeBPM : Button? = null
        var botaoVerdeS02 : Button? = null
        var botaoVerdeLogout : Button? = null

        var botaoVerdeBluetooth : Button? = null

    }

    private fun mudarCorTexto(navigationView: NavigationView, colorResId: Int) {
        val colorStateList = ColorStateList.valueOf(ContextCompat.getColor(this, colorResId))
        navigationView.setItemTextColor(colorStateList)
    }


    private fun updateUserData() {
        Log.d("UserData", "Atualizando dados do usuário")

        val sharedPref = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        val email = sharedPref.getString("USER_EMAIL", null)

        if (email != null) {

            val usuario = bd.getUsuario(email)

            if (usuario != null) {

                val userDnc = usuario.dnc
                val userGenero = usuario.genero
                val userAltura = usuario.altura.toString()
                val userPeso = usuario.peso.toString()

                val edt = sharedPref.edit()
                edt.putString("USER_DNC", userDnc)
                edt.putString("USER_GENERO", userGenero)
                edt.putString("USER_ALTURA", userAltura)
                edt.putString("USER_PESO", userPeso)
                edt.apply()

                updateMenu(userDnc, userGenero, userAltura, userPeso)
            } else {
                Log.e("UserData", "Usuário não encontrado.")
            }
        } else {
            Log.e("UserData", "Email do usuário não disponível.")
        }
    }

    private fun updateMenu(userDnc: String, userGenero: String, userAltura: String, userPeso: String) {
        Log.d("UpdateMenu", "Atualizando menu do usuário")

        val menu = navPerfil.menu
        menu.findItem(R.id.dwr_dtNascimento).title = "Data de nascimento          $userDnc"
        menu.findItem(R.id.dwr_genero).title = "Gênero                                $userGenero"
        menu.findItem(R.id.dwr_altura).title = "Altura                                       $userAltura cm"
        menu.findItem(R.id.dwr_peso).title = "Peso                                          $userPeso kg"

    }



    private fun updateHeader(nome: String?, email: String?) {
        Log.d("UpdateHeader", "Atualizando cabeçalho")

        val headerView = navPerfil.getHeaderView(0)
        if (headerView == null) {
            Log.e("UpdateHeader", "Cabeçalho não encontrado")
            return
        }

        val nomeUser: TextView = headerView.findViewById(R.id.txt_nomeUser)
        val emailUser: TextView = headerView.findViewById(R.id.txt_emailUser)

        if (nome != null && email != null) {
            nomeUser.text = nome
            emailUser.text = email
        } else {
            Log.e("UpdateHeader", "Nome ou email não disponíveis.")
        }
    }



    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receber)
    }

    fun homeDisp(view: View) {
        val intent = Intent(this, ActivityDispositivo::class.java)
        startActivity(intent)
    }

    fun homeCores(view: View) {
        val intent = Intent(this, ActivityCores::class.java)
        startActivity(intent)
    }

    fun homeConfig(view: View) {
        val intent = Intent(this, ActivityConfiguracoes::class.java)
        startActivity(intent)
    }

    private fun popupMedirBPM(message: String?) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.popup_frequencia)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val btMedirBPM: Button = dialog.findViewById(R.id.btn_medirBPM)
        val btFecharFrequencia: ImageView = dialog.findViewById(R.id.img_fecharFrequencia)
        val txtBPM: TextView = dialog.findViewById(R.id.txt_dadoBpm)

        SharedViews.botaoVerdeBPM = btMedirBPM

        val receber = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val data = intent?.getStringExtra("data")
                Log.d("Home", "Dados recebidos: $data")
                txtBPM.text = data
            }
        }
        LocalBroadcastManager.getInstance(this).registerReceiver(receber, IntentFilter("DATA_RECEIVED"))

        btMedirBPM.setOnClickListener {
            Toast.makeText(this, "Clicou em medir", Toast.LENGTH_LONG).show()
        }

        btFecharFrequencia.setOnClickListener {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(receber)
            dialog.dismiss()
        }

        dialog.show()
        aplicarTemaBPM()

    }

    private fun aplicarTemaBPM() {
        val sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val isTemaClaro = sharedPref.getBoolean("isTemaClaro", true)

        val corBotao2 = if (isTemaClaro) R.color.azul_claro else R.color.verde_logo_bottom
        SharedViews.botaoVerdeBPM?.setBackgroundColor(ContextCompat.getColor(this, corBotao2))
    }


    private fun popupMedirSP0(message : String?){
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.popup_oxigenacao)
        dialog.window?.setBackgroundDrawable((ColorDrawable(Color.TRANSPARENT)))

        val btMedirSP0 : Button = dialog.findViewById(R.id.btnMedir_ox)
        val btFecharOxigenacao : ImageView = dialog.findViewById(R.id.img_fecharSp0)
        val txtSp0 : TextView = dialog.findViewById(R.id.txtSp0)

        SharedViews.botaoVerdeS02 = btMedirSP0

        btMedirSP0.setOnClickListener{
            Toast.makeText(this, "Clicou em medir", Toast.LENGTH_LONG).show()
        }

        btFecharOxigenacao.setOnClickListener{
            dialog.dismiss()
        }

        dialog.show()
        aplicarTemaS02()
    }

    private fun aplicarTemaS02() {
        val sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val isTemaClaro = sharedPref.getBoolean("isTemaClaro", true)

        val corBotao3 = if (isTemaClaro) R.color.azul_claro else R.color.verde_logo_bottom
        SharedViews.botaoVerdeS02?.setBackgroundColor(ContextCompat.getColor(this, corBotao3))
    }

    private fun popupPrivacidade(message : String?){
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.popup_privacidade)
        dialog.window?.setBackgroundDrawable((ColorDrawable(Color.TRANSPARENT)))

        val window = dialog.window
        val layoutParams = window?.attributes
        layoutParams?.gravity = Gravity.BOTTOM
        window?.attributes = layoutParams

        val imgFecharPrivacidade : ImageView = dialog.findViewById(R.id.img_fecharPrivacidade)

        imgFecharPrivacidade.setOnClickListener{
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun popupPermissoes(mensagem: String?) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.popup_permissoes)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val window = dialog.window
        val layoutParams = window?.attributes
        layoutParams?.gravity = Gravity.BOTTOM
        window?.attributes = layoutParams

        val swtAcessoInfApp: SwitchCompat = dialog.findViewById(R.id.switch_acesso_informacoes)
        val swtAcessoInfAtividade: SwitchCompat = dialog.findViewById(R.id.switch_acesso_infAtiv)
        val swtAcessoNot: SwitchCompat = dialog.findViewById(R.id.switch_acesso_notificacoes)
        val imgFecharPermissoes: ImageView = dialog.findViewById(R.id.img_fecharPermissoes)

        val sharedPreferences = getSharedPreferences("AppPreferences", MODE_PRIVATE)
        swtAcessoInfApp.isChecked = sharedPreferences.getBoolean("swtAcessoInfApp", false)
        swtAcessoInfAtividade.isChecked = sharedPreferences.getBoolean("swtAcessoInfAtividade", false)
        swtAcessoNot.isChecked = sharedPreferences.getBoolean("swtAcessoNot", false)

        swtAcessoInfApp.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean("swtAcessoInfApp", isChecked).apply()
        }
        swtAcessoInfAtividade.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean("swtAcessoInfAtividade", isChecked).apply()
        }
        swtAcessoNot.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean("swtAcessoNot", isChecked).apply()
        }

        imgFecharPermissoes.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun popupLogout(message: String?) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.popup_logout)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val btSim: Button = dialog.findViewById(R.id.btn_sairSim)
        val btNao: Button = dialog.findViewById(R.id.btn_sairNao)

        SharedViews.botaoVerdeLogout = btSim

        btSim.setOnClickListener {
            val sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
            val editor = sharedPref.edit()
            editor.remove("isCadastroCompleto")
            editor.apply()

            Toast.makeText(this, "Saindo... ", Toast.LENGTH_SHORT).show()

            dialog.dismiss()

            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }

        btNao.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
        aplicarTemaLogout()
    }

    private fun aplicarTemaLogout() {
        val sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val isTemaClaro = sharedPref.getBoolean("isTemaClaro", true)

        val corBotao3 = if (isTemaClaro) R.color.azul_claro else R.color.verde_logo_bottom
        SharedViews.botaoVerdeLogout?.setBackgroundColor(ContextCompat.getColor(this, corBotao3))
    }


}
