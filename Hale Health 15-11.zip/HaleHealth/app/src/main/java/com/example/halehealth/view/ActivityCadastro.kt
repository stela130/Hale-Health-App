package com.example.halehealth.view

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.text.TextUtils
import android.text.TextWatcher
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.halehealth.AppDataBase.DBHelper
import com.example.halehealth.R


class ActivityCadastro : AppCompatActivity() {

    private lateinit var userName: EditText
    private lateinit var userEmail: EditText
    private lateinit var userSenha: EditText
    private lateinit var repSenha: EditText
    private lateinit var btnCadastrar: Button
    private lateinit var bd: DBHelper

    private lateinit var ocultarSenha: ImageView
    private lateinit var ocultarRepSenha: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro)
        enableEdgeToEdge()

        supportActionBar?.hide()

        ocultarSenha = findViewById(R.id.img_SenhaHide)
        ocultarRepSenha = findViewById(R.id.img_RepSenhaHide)

        userName = findViewById(R.id.edit_cadastroNome)
        userEmail = findViewById(R.id.edit_cadastroEmail)
        userSenha = findViewById(R.id.edit_cadastroSenha)
        repSenha = findViewById(R.id.edit_repetirSenha)
        btnCadastrar = findViewById(R.id.cadastroProximo)
        bd = DBHelper(this)

        val imgSenhaHide: ImageView = findViewById(R.id.img_SenhaHide)
        val imgRepSenhaHide: ImageView = findViewById(R.id.img_RepSenhaHide)
        val editSenha: EditText = findViewById(R.id.edit_cadastroSenha)
        val editRepSenha: EditText = findViewById(R.id.edit_repetirSenha)

        imgSenhaHide.setOnClickListener {
            if (editSenha.inputType == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                editSenha.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                imgSenhaHide.setImageResource(R.drawable.visible_pass)
            } else {
                editSenha.inputType = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                imgSenhaHide.setImageResource(R.drawable.hide_pass)
            }
            editSenha.setSelection(editSenha.length())
        }

        imgRepSenhaHide.setOnClickListener {
            if (editRepSenha.inputType == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                editRepSenha.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                imgRepSenhaHide.setImageResource(R.drawable.visible_pass)
            } else {
                editRepSenha.inputType = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                imgRepSenhaHide.setImageResource(R.drawable.hide_pass)
            }
            editRepSenha.setSelection(editRepSenha.length())
        }


        fun String.primeiraLetraMaiuscula(): String =
            split(" ").joinToString(" ") { it.lowercase().replaceFirstChar { char -> char.uppercase() } }


        btnCadastrar.setOnClickListener {
            val nometext = userName.text.toString().primeiraLetraMaiuscula()
            val emailtext = userEmail.text.toString()
            val senhatext = userSenha.text.toString()
            val reptSenhatext = repSenha.text.toString()

            if (TextUtils.isEmpty(nometext) || TextUtils.isEmpty(emailtext) || TextUtils.isEmpty(senhatext) || TextUtils.isEmpty(reptSenhatext)) {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show()
            } else {
                if (!emailtext.endsWith("@gmail.com") && !emailtext.endsWith("@hotmail.com") &&
                    !emailtext.endsWith("@outlook.com") && !emailtext.endsWith("@etec.sp.gov.br")) {
                    Toast.makeText(this, "Use um email válido", Toast.LENGTH_SHORT).show()
                } else {
                    val passwordError = senhaForte(senhatext)
                    if (passwordError != null) {
                        Toast.makeText(this, passwordError, Toast.LENGTH_SHORT).show()
                    } else if (senhatext != reptSenhatext) {
                        Toast.makeText(this, "As senhas não coincidem!", Toast.LENGTH_SHORT).show()
                    } else {
                        if (!emailCadastrado(emailtext)) {
                            Toast.makeText(this, "Cadastro 1/2", Toast.LENGTH_SHORT).show()
                            val intent = Intent(applicationContext, ActivityCadastro2::class.java)
                            intent.putExtra("nome", nometext)
                            intent.putExtra("email", emailtext)
                            intent.putExtra("senha", senhatext)
                            startActivity(intent)
                        } else {
                            Toast.makeText(this, "Email já cadastrado!", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
    }

    private fun emailCadastrado(email: String): Boolean {
        bd = DBHelper(this)
        return bd.emailExist(email)
    }

    fun senhaForte(password: String): String? {
        if (password.length < 9) {
            return "A senha deve ter no mínimo 9 caracteres."
        }
        if (!password.any { it.isLowerCase() }) {
            return "A senha deve conter pelo menos uma letra minúscula."
        }
        if (!password.any { it.isUpperCase() }) {
            return "A senha deve conter pelo menos uma letra maiúscula."
        }
        if (!password.any { it.isDigit() }) {
            return "A senha deve conter pelo menos um número."
        }
        if (!password.any { "!@#\$%^&*()-_=+[]{};:'\",.<>?/\\|`~".contains(it) }) {
            return "A senha deve conter pelo menos um caractere especial."
        }
        return null
    }



    fun toLogin(view: View) {
        val intent = Intent(this, ActivityLogin::class.java)
        startActivity(intent)
    }



}
