package com.example.halehealth.view

import android.content.Intent
import android.os.Bundle
import android.os.Looper
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.halehealth.MainActivity
import com.example.halehealth.R


class ActivitySplash : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        enableEdgeToEdge()
        supportActionBar?.hide()

        val sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val isCadastroCompleto = sharedPref.getBoolean("isCadastroCompleto", false)

        val nextActivity = if (isCadastroCompleto) {
            ActivityHome::class.java
        } else {
            MainActivity::class.java
        }

        android.os.Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, nextActivity))
            finish()
        }, 1500)
    }
}

