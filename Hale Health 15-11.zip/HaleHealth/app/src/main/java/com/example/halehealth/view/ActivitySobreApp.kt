package com.example.halehealth.view

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.halehealth.R



class ActivitySobreApp : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sobre_app)
    }

    fun voltarSobreApp(view: View) {
        finish()
    }

}