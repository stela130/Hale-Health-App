package com.example.halehealth.view

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.os.Build
import android.os.Build.VERSION
import android.os.Bundle
import android.view.View
import android.widget.Switch
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.contract.ActivityResultContracts.RequestPermission
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import com.example.halehealth.R

class PopupDispositivo : AppCompatActivity(){

    private var btPermissao = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.popup_bluetooth)

        }

    fun ativarBluetooth(view: View) {
        val btManager : BluetoothManager = getSystemService(BluetoothManager :: class.java)
        val btAdapter : BluetoothAdapter = btManager.adapter
        if (btAdapter == null) {
            Toast.makeText(this, "O dispositivo não suporta Bluetooth", Toast.LENGTH_LONG).show()
        } else {
            if (VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                btPermissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
            } else {
                btPermissionLauncher.launch(Manifest.permission.BLUETOOTH_ADMIN)
            }
        }
    }


    private val btPermissionLauncher = registerForActivityResult(RequestPermission()){
        maior:Boolean ->
        if(maior){
            val btManager : BluetoothManager = getSystemService(BluetoothManager :: class.java)
            val btAdapter : BluetoothAdapter? = btManager.adapter
            btPermissao = true
            if (btAdapter?.isEnabled == false) {
                val intent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                btResultLauncher.launch(intent)
            } else{
                BluetoothAtivar()
            }
        } else {

        }
    }

    private val btResultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        resultado : ActivityResult ->
        if(resultado.resultCode == RESULT_OK) {
            BluetoothAtivar()
        }
    }

    private fun BluetoothAtivar(){
        Toast.makeText(this, "Bluetooth ativado!", Toast.LENGTH_LONG).show()
    }

}