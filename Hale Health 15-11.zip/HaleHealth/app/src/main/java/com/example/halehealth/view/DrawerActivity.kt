package com.example.halehealth.view

import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.halehealth.AppDataBase.DBHelper
import com.example.halehealth.R

class DrawerActivity : AppCompatActivity() {

    private lateinit var bd: DBHelper
    private lateinit var txtNomeUser: TextView
    private lateinit var txtEmailUser: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.header_perfil)

        bd = DBHelper(this)

        txtNomeUser = findViewById(R.id.txt_nomeUser)
        txtEmailUser = findViewById(R.id.txt_emailUser)

        txtNomeUser.setText("Saly")

        }

}










