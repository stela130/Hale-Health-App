package com.example.halehealth.view

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.halehealth.AppDataBase.DBHelper
import com.example.halehealth.R

class ActivityLogin : AppCompatActivity() {

    private lateinit var loginEmail: EditText
    private lateinit var loginSenha: EditText
    private lateinit var btnEntrar: Button
    private lateinit var bd: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)


        loginEmail = findViewById(R.id.edit_loginEmail)
        loginSenha = findViewById(R.id.edit_loginSenha)
        btnEntrar = findViewById(R.id.btn_entrar)
        bd = DBHelper(this)


        val imgSenhaHide: ImageView = findViewById(R.id.img_loginSenhaHide)

        imgSenhaHide.setOnClickListener {
            if (loginSenha.inputType == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                loginSenha.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                imgSenhaHide.setImageResource(R.drawable.visible_pass)
            } else {
                loginSenha.inputType = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                imgSenhaHide.setImageResource(R.drawable.hide_pass)
            }
            loginSenha.setSelection(loginSenha.length())
        }


        btnEntrar.setOnClickListener {
            val logEmailtx = loginEmail.text.toString()
            val logSenhatx = loginSenha.text.toString()
            val logDnc = intent.getStringExtra("dncUsuario")
            val logGenero = intent.getStringExtra("generoUsuario")
            val logAltura = intent.getStringExtra("alturaUsuario")
            val logPeso = intent.getStringExtra("pesoUsuario")

            if (TextUtils.isEmpty(logEmailtx) || TextUtils.isEmpty(logSenhatx)) {
                Toast.makeText(this, "Adicione o Email e Senha", Toast.LENGTH_SHORT).show()
            } else {
                val user = bd.getUserByEmail(logEmailtx)
                if (user != null && bd.checkSenha(logEmailtx, logSenhatx)) {

                    val sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
                    val editor = sharedPref.edit()
                    editor.putBoolean("isCadastroCompleto", true)
                    editor.apply()

                    Toast.makeText(this, "Bem-vindo de volta!", Toast.LENGTH_SHORT).show()

                    val intent = Intent(this, ActivityHome::class.java).apply {
                        putExtra("USER_NAME", user.nome)
                        putExtra("USER_EMAIL", user.email)
                        putExtra("peso", logPeso)
                        putExtra("altura", logAltura)
                        putExtra("genero", logGenero)
                        putExtra("dnc", logDnc)
                    }
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "Usuário não existe", Toast.LENGTH_SHORT).show()
                }
            }
        }

    }

    fun irTelaCadastro(view: View) {
        val intent = Intent(this, ActivityCadastro::class.java)
        startActivity(intent)
    }

}

