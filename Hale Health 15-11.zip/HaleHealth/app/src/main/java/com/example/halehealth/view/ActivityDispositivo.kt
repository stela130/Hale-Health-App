package com.example.halehealth.view

import android.Manifest
import android.annotation.SuppressLint
import android.app.Dialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Build.VERSION
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.contract.ActivityResultContracts.RequestPermission
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.example.halehealth.MainActivity
import com.example.halehealth.R
import com.example.halehealth.view.ActivityHome.SharedViews
import com.google.android.material.bottomappbar.BottomAppBar
import java.io.IOException
import java.io.OutputStream
import java.util.UUID


@Suppress("DEPRECATION")
class ActivityDispositivo : AppCompatActivity() {

    private var btPermissao = false

    lateinit var bAdapter : BluetoothAdapter
    private lateinit var bDevice: BluetoothDevice
    private lateinit var bSocket: BluetoothSocket
    private lateinit var outputStream: OutputStream

    private val uuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val deviceName = "HC-05"

    private val NOT_ATIVO = "app_prefs"
    private val SWITCH_ATIVO_KEY = "switch_state"

    @SuppressLint("MissingPermission", "MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dispositivo)

        bAdapter = BluetoothAdapter.getDefaultAdapter()


        val txtOnOff= findViewById<TextView>(R.id.txtOnOff)
        val switchDisp = findViewById<SwitchCompat>(R.id.switchDispositivo)
        val btnEmparelhar = findViewById<Button>(R.id.btn_emparelhar)

        val swtNotDisp = findViewById<SwitchCompat>(R.id.switch_not_disp)

        val btConfigNot = findViewById<AppCompatButton>(R.id.btn_config_notif)

        val btSobreDisp = findViewById<AppCompatButton>(R.id.btn_sobre_disp)

        checkPermissions()

        ActivityHome.SharedViews.fitaPerfil3 = findViewById(R.id.fita_perfil3)

        ActivityHome.SharedViews.dadosSimb3 = findViewById(R.id.dados_simb3)
        ActivityHome.SharedViews.coresSimb3 = findViewById(R.id.cores_simb3)
        ActivityHome.SharedViews.dispositivoSimb3 = findViewById(R.id.dispositivo_simb3)
        ActivityHome.SharedViews.configSimb3 = findViewById(R.id.config_simb3)

        ActivityHome.SharedViews.background3 = findViewById(R.id.tela_dispositivo)
        ActivityHome.SharedViews.tituloCores = findViewById(R.id.txt_dispositivo)

        ActivityHome.SharedViews.linhaCoresDispositivo = findViewById(R.id.btn_notificacoes)
        ActivityHome.SharedViews.linhaCoresDispositivo2 = findViewById(R.id.btn_config_notif)
        ActivityHome.SharedViews.linhaCoresDispositivo3 = findViewById(R.id.btn_sobre_disp)
        ActivityHome.SharedViews.retaDispositivo = findViewById(R.id.linha_dispositivo)
        ActivityHome.SharedViews.botaoVerde = findViewById(R.id.btn_emparelhar)
        ActivityHome.SharedViews.textVerde = findViewById(R.id.txt_NomeBracelete)

        ActivityHome.SharedViews.retanguloDadosDisp = findViewById(R.id.dados_dispositivo)

        aplicarTemaDispositivo()



        if (bAdapter.isEnabled){
            switchDisp.setChecked(true)
            txtOnOff.text = "Ligado"
        }

        switchDisp.setOnClickListener{

            if(!bAdapter.isEnabled){

                val message : String = "Popup Dispositivo"
                popupDisp(message)
                txtOnOff.text = "Ligado"

            } else {

                txtOnOff.text = "Não ativado"
                switchDisp.setChecked(false)
                bAdapter.disable()
        }
    }

        btConfigNot.setOnClickListener{
            val email : String = "Popup Configuracoes das Notificacoes"
            popupConfiguracoesNotif(email)
        }

        btSobreDisp.setOnClickListener{
            val mensagem : String = "Popup Sobre Dispositvo"
            popupSobreDisp(mensagem)
        }

        btnEmparelhar.setOnClickListener{

            val pairedDevices = bAdapter.bondedDevices
            if (pairedDevices.isNotEmpty()) {
                for (device in pairedDevices) {
                    Log.d("HC", "Dispositivo: ${device.name}, ${device.address}")
                    if (device.name == deviceName) {
                        bDevice = device
                        try {
                            bSocket = bDevice.createRfcommSocketToServiceRecord(uuid)
                            bAdapter.cancelDiscovery()
                            bSocket.connect()
                            outputStream = bSocket.outputStream
                            Toast.makeText(this, "Conectado ao Hale Bracelete", Toast.LENGTH_LONG).show()

                            ConnectedThread(bSocket).start()


                        } catch (e: IOException) {
                            Log.e("HC", "Falha na conexão: ${e.message}")
                            Toast.makeText(this, "Falha na conexão: ${e.message}", Toast.LENGTH_SHORT).show()

                            Toast.makeText(this, "Emparelhe o Bluetooth com o HC-05 (sistema do seu celular): ${e.message}", Toast.LENGTH_SHORT).show()

                            try {
                                bSocket.close()

                            } catch (closeException: IOException) {
                                Log.e("HC", "Erro ao fechar o socket: ${closeException.message}")
                            }
                        }
                        break
                    }
                }
            } else {
                Toast.makeText(this, "Nenhum dispositivo emparelhado encontrado", Toast.LENGTH_SHORT).show()
        }
    }

        val sharedPref = getSharedPreferences(NOT_ATIVO, MODE_PRIVATE)
        val isSwitchOn = sharedPref.getBoolean(SWITCH_ATIVO_KEY, false)
        swtNotDisp.isChecked = isSwitchOn

        swtNotDisp.setOnClickListener {
            val editor = sharedPref.edit()
            editor.putBoolean(SWITCH_ATIVO_KEY, swtNotDisp.isChecked)
            editor.apply()

            if (swtNotDisp.isChecked) {
                Toast.makeText(this, "Notificação está ativada!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Notificação está desativado!", Toast.LENGTH_SHORT).show()
            }
        }

}

    private fun aplicarTemaDispositivo() {
        val sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val isTemaClaro = sharedPref.getBoolean("isTemaClaro", true)

        ActivityHome.SharedViews.fitaPerfil2?.setBackgroundResource(if (isTemaClaro) R.drawable.fita_perfil else R.drawable.fita_verde_perfil)
        ActivityHome.SharedViews.fitaPerfil3?.setBackgroundResource(if (isTemaClaro) R.drawable.fita_perfil else R.drawable.fita_verde_perfil)
        ActivityHome.SharedViews.fitaPerfil4?.setBackgroundResource(if (isTemaClaro) R.drawable.fita_perfil else R.drawable.fita_verde_perfil)

        val colorResId = if (isTemaClaro) R.color.azul_logo_bottom else R.color.verde_logo_bottom
        val colorRes = if (isTemaClaro) R.color.clicadoNav else R.color.verde_clicadoNav

        ActivityHome.SharedViews.dadosSimb3?.setColorFilter(ContextCompat.getColor(this, colorResId), PorterDuff.Mode.SRC_IN)
        ActivityHome.SharedViews.coresSimb3?.setColorFilter(ContextCompat.getColor(this, colorResId), PorterDuff.Mode.SRC_IN)
        ActivityHome.SharedViews.dispositivoSimb3?.setColorFilter(ContextCompat.getColor(this, colorRes), PorterDuff.Mode.SRC_IN)
        ActivityHome.SharedViews.configSimb3?.setColorFilter(ContextCompat.getColor(this, colorResId), PorterDuff.Mode.SRC_IN)

        val titulo = if (isTemaClaro) R.color.white else R.color.black
        val corHale = if (isTemaClaro) R.color.azul else R.color.verde_logo_bottom
        val corBotao = if (isTemaClaro) R.color.azul_claro else R.color.verde_logo_bottom

        ActivityHome.SharedViews.background3?.setBackgroundResource(if (isTemaClaro) R.drawable.background_padrao else R.drawable.background_padrao_claro)
        ActivityHome.SharedViews.tituloCores?.setTextColor(ContextCompat.getColor(this, titulo))

        ActivityHome.SharedViews.botaoVerde?.setBackgroundColor(ContextCompat.getColor(this, corBotao))
        ActivityHome.SharedViews.textVerde?.setTextColor(ContextCompat.getColor(this, corHale))

        ActivityHome.SharedViews.linhaCoresDispositivo?.setBackgroundResource(if (isTemaClaro) R.drawable.botao_padrao else R.drawable.botao_padrao_claro)
        ActivityHome.SharedViews.linhaCoresDispositivo2?.setBackgroundResource(if (isTemaClaro) R.drawable.botao_padrao else R.drawable.botao_padrao_claro)
        ActivityHome.SharedViews.linhaCoresDispositivo3?.setBackgroundResource(if (isTemaClaro) R.drawable.botao_padrao else R.drawable.botao_padrao_claro)
        ActivityHome.SharedViews.retaDispositivo?.setBackgroundResource(if (isTemaClaro) R.drawable.linha_branca else R.drawable.linha_preta)

        ActivityHome.SharedViews.retanguloDadosDisp?.setBackgroundResource(if (isTemaClaro) R.drawable.retangulo_dados else R.drawable.retangulo_dados_claro)

        val bottomAppbar3 = if (isTemaClaro) R.color.nav1 else R.color.navClaro

        val bottomAppBar3 = findViewById<BottomAppBar>(R.id.barra_nav3)
        bottomAppBar3.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, bottomAppbar3))
    }

    private fun popupDisp (message : String?) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.popup_bluetooth)
        dialog.window?.setBackgroundDrawable((ColorDrawable(Color.TRANSPARENT)))

        val btAtivar : Button = dialog.findViewById(R.id.popupAtivar)
        val btFechar : Button = dialog.findViewById(R.id.popupFechar)

        SharedViews.botaoVerdeBluetooth = btAtivar

        btFechar.setOnClickListener{
            dialog.dismiss()
            val txtOnOff= findViewById<TextView>(R.id.txtOnOff)
            val switchDisp = findViewById<SwitchCompat>(R.id.switchDispositivo)
            txtOnOff.text = "Não ativado"
            switchDisp.setChecked(false)

            val shdPref = getSharedPreferences("SwitchDesconexao", Context.MODE_PRIVATE)
            val edt = shdPref.edit()

            edt.putBoolean("switch_false", true)
            edt.apply()
        }

        btAtivar.setOnClickListener{
            val btManager : BluetoothManager = getSystemService(BluetoothManager :: class.java)
            val btAdapter : BluetoothAdapter = btManager.adapter
            if (btAdapter == null) {
                Toast.makeText(this, "O dispositivo não suporta Bluetooth", Toast.LENGTH_LONG).show()
            } else {
                if (VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    btPermissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
                } else {
                    btPermissionLauncher.launch(Manifest.permission.BLUETOOTH_ADMIN)
                }

            }
            dialog.dismiss()
        }

        dialog.show()
        aplicarTemaBluetooth()
    }

    private fun aplicarTemaBluetooth() {
        val sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val isTemaClaro = sharedPref.getBoolean("isTemaClaro", true)

        val corBotao3 = if (isTemaClaro) R.color.azul_claro else R.color.verde_logo_bottom
        SharedViews.botaoVerdeBluetooth?.setBackgroundColor(ContextCompat.getColor(this, corBotao3))
    }

    private val btPermissionLauncher = registerForActivityResult(RequestPermission()){
            maior:Boolean ->
        if(maior){
            val btManager : BluetoothManager = getSystemService(BluetoothManager :: class.java)
            val btAdapter : BluetoothAdapter? = btManager.adapter

            btPermissao = true
            if (btAdapter?.isEnabled == false) {
                val intent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                btResultLauncher.launch(intent)
            } else {
                BluetoothAtivado()
            }
        } else {

        }
    }


    private val btResultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            resultado : ActivityResult ->
        if (resultado.resultCode == RESULT_OK) {

            BluetoothAtivar()

        } else {

            val txtOnOff= findViewById<TextView>(R.id.txtOnOff)
            val switchDisp = findViewById<SwitchCompat>(R.id.switchDispositivo)

            switchDisp.setChecked(false)
            txtOnOff.text = "Não ativado"
            Toast.makeText(this, "Clique em permitir!", Toast.LENGTH_LONG).show()
        }
    }



    private fun BluetoothAtivar(){
        Toast.makeText(this, "O Bluetooth foi ativado!", Toast.LENGTH_LONG).show()
    }

    private fun BluetoothAtivado(){
        Toast.makeText(this, "O Bluetooth já está ativado!", Toast.LENGTH_LONG).show()
    }


    fun dispHome(view: View) {
        val intent = Intent(this, ActivityHome::class.java)
        startActivity(intent)
    }

    fun dispCores(view: View) {
        val intent = Intent(this, ActivityCores::class.java)
        startActivity(intent)
    }

    fun dispConfig(view: View) {
        val intent = Intent(this, ActivityConfiguracoes::class.java)
        startActivity(intent)
    }

    private fun popupConfiguracoesNotif(email: String?) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.popup_config_notific)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val window = dialog.window
        val layoutParams = window?.attributes
        layoutParams?.gravity = Gravity.BOTTOM
        window?.attributes = layoutParams

        val swtBPM: SwitchCompat = dialog.findViewById(R.id.switch_not_bpm)
        val swtO2: SwitchCompat = dialog.findViewById(R.id.switch_not_o2)
        val imgFecharConfig: ImageView = dialog.findViewById(R.id.img_fecharConfigNotif)

        if (email != null) {
            recuperarEstadoDoSwitch(email, swtBPM, swtO2)
        }

        swtBPM.setOnCheckedChangeListener { _, isChecked ->
            salvarEstadoDoSwitch(email, "switch_bpm", isChecked)
        }

        swtO2.setOnCheckedChangeListener { _, isChecked ->
            salvarEstadoDoSwitch(email, "switch_o2", isChecked)
        }

        imgFecharConfig.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun popupSobreDisp(message: String?) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.popup_sobre_disp)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val window = dialog.window
        val layoutParams = window?.attributes
        layoutParams?.gravity = Gravity.BOTTOM
        window?.attributes = layoutParams

        val imgSairPopupDispositivo: ImageView = dialog.findViewById(R.id.img_fecharConfigNotif)

        imgSairPopupDispositivo.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun salvarEstadoDoSwitch(email: String?, key: String, value: Boolean) {
        if (email == null) return
        val prefs = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        val editor = prefs.edit()
        editor.putBoolean("${email}_$key", value)
        editor.apply()
    }

    private fun recuperarEstadoDoSwitch(email: String?, swtBPM: SwitchCompat, swtO2: SwitchCompat) {
        if (email == null) return
        val prefs = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        swtBPM.isChecked = prefs.getBoolean("${email}_switch_bpm", false)
        swtO2.isChecked = prefs.getBoolean("${email}_switch_o2", false)
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            bSocket.close()
        } catch (e: IOException) {
            Log.e("HC", "Erro ao fechar o socket: ${e.message}")
        }
    }


    private fun checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.BLUETOOTH, Manifest.permission.BLUETOOTH_ADMIN, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.ACCESS_FINE_LOCATION),
                1)
        }
    }

    inner class ConnectedThread(private val socket: BluetoothSocket) : Thread() {
        override fun run() {
            val buffer = ByteArray(1024)
            val inputStream = socket.inputStream

            while (true) {
                try {
                    val bytes = inputStream.read(buffer)
                    val receivedData = String(buffer, 0, bytes)
                    Log.d("HC", "Dados recebidos: $receivedData")

                    val intent = Intent("DATA_RECEIVED")
                    intent.putExtra("data", receivedData)
                    LocalBroadcastManager.getInstance(this@ActivityDispositivo)
                        .sendBroadcast(intent)

                } catch (e: IOException) {
                    Log.e("HC", "Erro na leitura: ${e.message}")
                    break
                }
            }
        }
    }


}