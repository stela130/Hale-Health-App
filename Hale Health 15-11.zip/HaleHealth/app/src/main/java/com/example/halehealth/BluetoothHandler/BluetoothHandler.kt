package com.example.halehealth.BluetoothHandler

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.util.Log
import java.io.IOException
import java.util.UUID

@SuppressLint("MissingPermission")
class BluetoothHandler(
    private val btAdapter: BluetoothAdapter,
    private val macAddress: String
) : Thread() {
    fun createSocket(device: BluetoothDevice): BluetoothSocket {
        val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        return device.createRfcommSocketToServiceRecord(uuid)
    }


    override fun run() {
        var bluetoothSocket: BluetoothSocket? = null
        if(bluetoothSocket == null || !bluetoothSocket.isConnected) {
            val device = btAdapter.getRemoteDevice(macAddress)
            try {
                bluetoothSocket = createSocket(device)
            }catch (e: IOException) {
                Log.d("Erro na conexão", "Erro na criacão do socket!")
            }

            if(bluetoothSocket != null && bluetoothSocket.isConnected) {
                Log.d("Conectando", "Conectado ao ${device.name}")
            } else {
                bluetoothSocket?.close()
            }
        }
    }

}