package com.example.halehealth.view

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.PorterDuff
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.halehealth.R
import com.google.android.material.bottomappbar.BottomAppBar

class ActivityCores : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cores)

        ActivityHome.SharedViews.fitaPerfil2 = findViewById(R.id.fita_perfil2)

        ActivityHome.SharedViews.dadosSimb2 = findViewById(R.id.dados_simb2)
        ActivityHome.SharedViews.coresSimb2 = findViewById(R.id.cores_simb2)
        ActivityHome.SharedViews.dispositivoSimb2 = findViewById(R.id.dispositivo_simb2)
        ActivityHome.SharedViews.configSimb2 = findViewById(R.id.config_simb2)

        ActivityHome.SharedViews.background2 = findViewById(R.id.tela_cores)
        ActivityHome.SharedViews.tituloCores = findViewById(R.id.txt_coresLed)

        aplicarTemaCores()
        }

    private fun aplicarTemaCores() {
        val sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val isTemaClaro = sharedPref.getBoolean("isTemaClaro", true)

        ActivityHome.SharedViews.fitaPerfil2?.setBackgroundResource(if (isTemaClaro) R.drawable.fita_perfil else R.drawable.fita_verde_perfil)
        ActivityHome.SharedViews.fitaPerfil3?.setBackgroundResource(if (isTemaClaro) R.drawable.fita_perfil else R.drawable.fita_verde_perfil)
        ActivityHome.SharedViews.fitaPerfil4?.setBackgroundResource(if (isTemaClaro) R.drawable.fita_perfil else R.drawable.fita_verde_perfil)

        val colorResId = if (isTemaClaro) R.color.azul_logo_bottom else R.color.verde_logo_bottom
        val colorRes = if (isTemaClaro) R.color.clicadoNav else R.color.verde_clicadoNav

        ActivityHome.SharedViews.dadosSimb2?.setColorFilter(ContextCompat.getColor(this, colorResId), PorterDuff.Mode.SRC_IN)
        ActivityHome.SharedViews.coresSimb2?.setColorFilter(ContextCompat.getColor(this, colorRes), PorterDuff.Mode.SRC_IN)
        ActivityHome.SharedViews.dispositivoSimb2?.setColorFilter(ContextCompat.getColor(this, colorResId), PorterDuff.Mode.SRC_IN)
        ActivityHome.SharedViews.configSimb2?.setColorFilter(ContextCompat.getColor(this, colorResId), PorterDuff.Mode.SRC_IN)

        val titulo = if (isTemaClaro) R.color.white else R.color.black

        ActivityHome.SharedViews.background2?.setBackgroundResource(if (isTemaClaro) R.drawable.background_padrao else R.drawable.background_padrao_claro)
        ActivityHome.SharedViews.tituloCores?.setTextColor(ContextCompat.getColor(this, titulo))


        val bottomAppbar2 = if (isTemaClaro) R.color.nav1 else R.color.navClaro

        val bottomAppBar2 = findViewById<BottomAppBar>(R.id.barra_nav2)
        bottomAppBar2.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, bottomAppbar2))




    }

    fun coresDisp(view: View) {
        val intent = Intent(this, ActivityDispositivo::class.java)
        startActivity(intent)
    }

    fun coresHome(view: View) {
        val intent = Intent(this, ActivityHome::class.java)
        startActivity(intent)
    }

    fun coresConfig(view: View) {
        val intent = Intent(this, ActivityConfiguracoes::class.java)
        startActivity(intent)
    }
}