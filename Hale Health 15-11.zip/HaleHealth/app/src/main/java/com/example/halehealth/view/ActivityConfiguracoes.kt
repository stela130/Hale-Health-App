package com.example.halehealth.view

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.PorterDuff
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import com.example.halehealth.R
import com.google.android.material.bottomappbar.BottomAppBar

class ActivityConfiguracoes : AppCompatActivity() {

    private lateinit var swtAlertaConexao : SwitchCompat

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_configuracoes)

        swtAlertaConexao = findViewById(R.id.switch_alert_con)

        ActivityHome.SharedViews.fitaPerfil4 = findViewById(R.id.fita_perfil4)

        ActivityHome.SharedViews.dadosSimb4 = findViewById(R.id.dados_simb4)
        ActivityHome.SharedViews.coresSimb4 = findViewById(R.id.cores_simb4)
        ActivityHome.SharedViews.dispositivoSimb4 = findViewById(R.id.dispositivo_simb4)
        ActivityHome.SharedViews.configSimb4 = findViewById(R.id.config_simb4)

        ActivityHome.SharedViews.background4 = findViewById(R.id.tela_configuracoes)
        ActivityHome.SharedViews.tituloCores = findViewById(R.id.txt_configuracoes)

        ActivityHome.SharedViews.linhaCoresConfiguracoes = findViewById(R.id.btn_not_app)
        ActivityHome.SharedViews.linhaCoresConfiguracoes2 = findViewById(R.id.btn_alert_con)
        ActivityHome.SharedViews.linhaCoresConfiguracoes3meio = findViewById(R.id.btn_sobre_empresa)
        ActivityHome.SharedViews.linhaCoresConfiguracoes3 = findViewById(R.id.btn_sobre_app)
        ActivityHome.SharedViews.linhaCoresConfiguracoes4 = findViewById(R.id.btn_perg_freq)
        ActivityHome.SharedViews.linhaCoresConfiguracoes5 = findViewById(R.id.btn_manual)


        aplicarTemaConfiguracoes()

    }

    private fun aplicarTemaConfiguracoes() {
        val sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val isTemaClaro = sharedPref.getBoolean("isTemaClaro", true)

        ActivityHome.SharedViews.fitaPerfil2?.setBackgroundResource(if (isTemaClaro) R.drawable.fita_perfil else R.drawable.fita_verde_perfil)
        ActivityHome.SharedViews.fitaPerfil3?.setBackgroundResource(if (isTemaClaro) R.drawable.fita_perfil else R.drawable.fita_verde_perfil)
        ActivityHome.SharedViews.fitaPerfil4?.setBackgroundResource(if (isTemaClaro) R.drawable.fita_perfil else R.drawable.fita_verde_perfil)

        val colorResId = if (isTemaClaro) R.color.azul_logo_bottom else R.color.verde_logo_bottom
        val colorRes = if (isTemaClaro) R.color.clicadoNav else R.color.verde_clicadoNav

        ActivityHome.SharedViews.dadosSimb4?.setColorFilter(ContextCompat.getColor(this, colorResId), PorterDuff.Mode.SRC_IN)
        ActivityHome.SharedViews.coresSimb4?.setColorFilter(ContextCompat.getColor(this, colorResId), PorterDuff.Mode.SRC_IN)
        ActivityHome.SharedViews.dispositivoSimb4?.setColorFilter(ContextCompat.getColor(this, colorResId), PorterDuff.Mode.SRC_IN)
        ActivityHome.SharedViews.configSimb4?.setColorFilter(ContextCompat.getColor(this, colorRes), PorterDuff.Mode.SRC_IN)

        val titulo2 = if (isTemaClaro) R.color.white else R.color.black

        ActivityHome.SharedViews.background4?.setBackgroundResource(if (isTemaClaro) R.drawable.background_padrao else R.drawable.background_padrao_claro)
        ActivityHome.SharedViews.tituloCores?.setTextColor(ContextCompat.getColor(this, titulo2))

        ActivityHome.SharedViews.linhaCoresConfiguracoes?.setBackgroundResource(if (isTemaClaro) R.drawable.botao_padrao else R.drawable.botao_padrao_claro)
        ActivityHome.SharedViews.linhaCoresConfiguracoes2?.setBackgroundResource(if (isTemaClaro) R.drawable.botao_padrao else R.drawable.botao_padrao_claro)
        ActivityHome.SharedViews.linhaCoresConfiguracoes3?.setBackgroundResource(if (isTemaClaro) R.drawable.botao_padrao else R.drawable.botao_padrao_claro)
        ActivityHome.SharedViews.linhaCoresConfiguracoes3meio?.setBackgroundResource(if (isTemaClaro) R.drawable.botao_padrao else R.drawable.botao_padrao_claro)
        ActivityHome.SharedViews.linhaCoresConfiguracoes4?.setBackgroundResource(if (isTemaClaro) R.drawable.botao_padrao else R.drawable.botao_padrao_claro)
        ActivityHome.SharedViews.linhaCoresConfiguracoes5?.setBackgroundResource(if (isTemaClaro) R.drawable.botao_padrao else R.drawable.botao_padrao_claro)

        val bottomAppbar4 = if (isTemaClaro) R.color.nav1 else R.color.navClaro

        val bottomAppBar4 = findViewById<BottomAppBar>(R.id.barra_nav4)
        bottomAppBar4.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, bottomAppbar4))

    }

    fun configDisp(view: View) {
        val intent = Intent(this, ActivityDispositivo::class.java)
        startActivity(intent)
    }

    fun configHome(view: View) {
        val intent = Intent(this, ActivityHome::class.java)
        startActivity(intent)
    }

    fun configCores(view: View) {
        val intent = Intent(this, ActivityCores::class.java)
        startActivity(intent)
    }

    fun manualDisp(view: View) {
        val intent = Intent(this, ActivityManualDispositivo::class.java)
        startActivity(intent)
    }

    fun sobreApp(view: View) {
        val intent = Intent(this, ActivitySobreApp::class.java)
        startActivity(intent)
    }

    fun sobreEmpresa(view: View) {
        val intent = Intent(this, ActivitySobreEmpresa::class.java)
        startActivity(intent)
    }
}